# Iteration 009 — Remove optional `scripts/` folder

## Goal

Drop helper scripts that are not required for runtime, Docker, or CI; keep `backend/requirements.txt` (Docker + GitHub Actions).

## Changes

- Removed `scripts/` (`run_local.sh`, `smoke_test.sh`, `prepare_data.py`, `download_dataset.py`).
- **README**: removed one-command helper; documented running backend and frontend in separate terminals.

## Notes

- `backend/requirements.txt` retained — used by `backend/Dockerfile` and `.github/workflows/ci.yml`.
